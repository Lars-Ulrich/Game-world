#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>

// ── Objects ───────────────────────────────────────────────────
LiquidCrystal_I2C lcd(0x27, 16, 2);
ArduinoLEDMatrix  matrix;

// ── Joystick pins ─────────────────────────────────────────────
const int joyX   = A0;
const int joyY   = A1;
const int joyBtn = 2;

// ── Joystick values ───────────────────────────────────────────
int valJoyX = 0;
int valJoyY = 0;

int keyW = 0;
int keyA = 0;
int keyS = 0;
int keyD = 0;

// ── Counter for "Move Jango" (only prints once when idle) ─────
int counter = 0;

// ── Track which matrix frame is showing ───────────────────────
bool showing444    = false;
unsigned long matrixTimer = 0;

// =============================================================
//  SETUP
// =============================================================
void setup() {
  Serial.begin(9600);
  Serial.println("TheNavigator starting...");

  pinMode(joyBtn, INPUT_PULLUP);

  // Start LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Key held:");

  // Start matrix
  matrix.begin();

  // Show "444" at startup
  matrix.beginDraw();
    matrix.stroke(0xFFFFFFFF);
    matrix.textFont(Font_4x6);
    matrix.beginText(1, 1, 0xFFFFFF);
    matrix.println("444");
    matrix.endText();
  matrix.endDraw();

  showing444 = true;
  matrixTimer = millis();

  Serial.println("Matrix: showing 444");
}

// =============================================================
//  LOOP  –  both matrix and joystick always run
// =============================================================
void loop() {

  // ── LED MATRIX ─────────────────────────────────────────────
  // Show "444" for 3 seconds, then scroll name, then repeat

  if (showing444 && millis() - matrixTimer >= 3000) {
    // 3 seconds passed → scroll name
    Serial.println("Matrix: scrolling name");

    matrix.beginDraw();
      matrix.stroke(0xFFFFFFFF);
      matrix.textScrollSpeed(80);
      matrix.textFont(Font_5x7);
      matrix.beginText(0, 1, 0xFFFFFF);
      matrix.println(" Lars Ulrich - BP03 ");
      matrix.endText(SCROLL_LEFT);
    matrix.endDraw();

    showing444 = false;
    matrixTimer = millis();
  }

  if (!showing444 && millis() - matrixTimer >= 5000) {
    // 5 seconds passed → show "444" again
    matrix.beginDraw();
      matrix.stroke(0xFFFFFFFF);
      matrix.textFont(Font_4x6);
      matrix.beginText(1, 1, 0xFFFFFF);
      matrix.println("444");
      matrix.endText();
    matrix.endDraw();

    showing444 = true;
    matrixTimer = millis();

    Serial.println("Matrix: showing 444");
  }

  // ── JOYSTICK ───────────────────────────────────────────────
  // Always read joystick and update LCD + Serial

  valJoyX = analogRead(joyX);
  valJoyY = analogRead(joyY);

  keyA = map(valJoyX, 0,   500,  0, 100);
  keyD = map(valJoyX, 505, 994,  100, 0);
  keyW = map(valJoyY, 0,   527,  0, 100);
  keyS = map(valJoyY, 530, 1023, 100, 0);

  if (keyW <= 95) {
    counter = 0;
    Serial.println("W");
    lcd.setCursor(0, 1);
    lcd.print("W               ");
    delay(50);
  }

  else if (keyS <= 95) {
    counter = 0;
    Serial.println("S");
    lcd.setCursor(0, 1);
    lcd.print("S               ");
    delay(50);
  }

  else if (keyA <= 95) {
    counter = 0;
    Serial.println("A");
    lcd.setCursor(0, 1);
    lcd.print("A               ");
    delay(50);
  }

  else if (keyD <= 95) {
    counter = 0;
    Serial.println("D");
    lcd.setCursor(0, 1);
    lcd.print("D               ");
    delay(50);
  }

  else if (keyW == 100 && keyA == 100 && keyS == 100 && keyD == 100) {
    if (counter == 0) {
      counter = 1;
      Serial.println("Move Jango");
      lcd.setCursor(0, 1);
      lcd.print("-               ");
    }
  }
}

